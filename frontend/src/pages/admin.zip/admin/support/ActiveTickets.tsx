import React, { useState } from "react";
import styles from "./ActiveTickets.module.css";

type TicketStatus = "Open" | "In Progress" | "Solved";

type Ticket = {
    id: string;
    subject: string;
    user: string;
    category: string;
    priority: "Low" | "Medium" | "High";
    status: TicketStatus;
    assignedTo: string;
    created: string;
};

const activeTickets: Ticket[] = [
    {
        id: "TICKET3000",
        subject: "Login Issue",
        user: "User 21",
        category: "Technical",
        priority: "Low",
        status: "Open",
        assignedTo: "Agent 3",
        created: "14/01/2026",
    },
    {
        id: "TICKET3001",
        subject: "Login Issue",
        user: "User 13",
        category: "General",
        priority: "High",
        status: "In Progress",
        assignedTo: "Agent 4",
        created: "16/01/2026",
    },
    {
        id: "TICKET3004",
        subject: "Payment Problem",
        user: "User 21",
        category: "Technical",
        priority: "High",
        status: "In Progress",
        assignedTo: "Agent 2",
        created: "17/01/2026",
    },
];

const solvedTickets: Ticket[] = [
    {
        id: "TICKET2990",
        subject: "Profile Update",
        user: "User 55",
        category: "General",
        priority: "Medium",
        status: "Solved",
        assignedTo: "Agent 1",
        created: "10/01/2026",
    },
    {
        id: "TICKET2987",
        subject: "Email Verification",
        user: "User 44",
        category: "Technical",
        priority: "Low",
        status: "Solved",
        assignedTo: "Agent 2",
        created: "08/01/2026",
    },
];

const Tickets: React.FC = () => {
    const [tab, setTab] = useState<"active" | "solved">("active");

    const data = tab === "active" ? activeTickets : solvedTickets;

    return (
        <div className={styles.page}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>{tab === "active" ? "Active Tickets" : "Solved Tickets"}</h2>

                <div className={styles.tabs}>
                    <span
                        className={tab === "active" ? styles.activeTab : ""}
                        onClick={() => setTab("active")}
                    >
                        Active ({activeTickets.length})
                    </span>
                    <span
                        className={tab === "solved" ? styles.activeTab : ""}
                        onClick={() => setTab("solved")}
                    >
                        Solved ({solvedTickets.length})
                    </span>
                </div>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Subject</th>
                            <th>User</th>
                            <th>Category</th>
                            <th>Priority</th>
                            <th>Status</th>
                            <th>Assigned To</th>
                            <th>Created</th>
                            {tab === "active" && <th>Actions</th>}
                        </tr>
                    </thead>

                    <tbody>
                        {data.map((t) => (
                            <tr key={t.id}>
                                <td className={styles.ticketId}>{t.id}</td>
                                <td>
                                    <strong>{t.subject}</strong>
                                    <small className={styles.subText}>
                                        Last update: {t.created}
                                    </small>
                                </td>
                                <td>{t.user}</td>
                                <td>{t.category}</td>
                                <td>
                                    <span
                                        className={`${styles.badge} ${styles[t.priority.toLowerCase()]}`}
                                    >
                                        {t.priority}
                                    </span>
                                </td>
                                <td>
                                    <span
                                        className={`${styles.badge} ${t.status === "Solved"
                                            ? styles.solved
                                            : t.status === "Open"
                                                ? styles.open
                                                : styles.inProgress
                                            }`}
                                    >
                                        {t.status}
                                    </span>
                                </td>
                                <td>{t.assignedTo}</td>
                                <td>{t.created}</td>
                                {tab === "active" && (
                                    <td className={styles.actions}>
                                        <button className={styles.view}>View</button>
                                        <button className={styles.resolve}>Resolve</button>
                                        <button className={styles.assign}>Assign</button>
                                    </td>
                                )}
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Tickets;
