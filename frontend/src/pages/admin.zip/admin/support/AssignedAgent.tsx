import React, { useState } from "react";
import styles from "./AssignedAgent.module.css";

type AgentStatus = "Active" | "Away" | "Inactive";

type Agent = {
    name: string;
    email: string;
    role: string;
    tickets: number;
    status: AgentStatus;
    lastActive: string;
};

const agents: Agent[] = [
    {
        name: "Agent 1",
        email: "agent1@enterprise.com",
        role: "Senior Support",
        tickets: 45,
        status: "Active",
        lastActive: "2 hours ago",
    },
    {
        name: "Agent 2",
        email: "agent2@enterprise.com",
        role: "Support",
        tickets: 32,
        status: "Active",
        lastActive: "1 hour ago",
    },
    {
        name: "Agent 3",
        email: "agent3@enterprise.com",
        role: "Technical Support",
        tickets: 28,
        status: "Active",
        lastActive: "Just now",
    },
    {
        name: "Agent 4",
        email: "agent4@enterprise.com",
        role: "Billing Support",
        tickets: 15,
        status: "Away",
        lastActive: "5 hours ago",
    },
    {
        name: "Agent 5",
        email: "agent5@enterprise.com",
        role: "Support",
        tickets: 23,
        status: "Inactive",
        lastActive: "2 days ago",
    },
];

const SupportAgents: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<number | null>(null);

    return (
        <div className={styles.wrapper}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Support Agents</h2>
                <button className={styles.addBtn}>+ Add Agent</button>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Agent</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Assigned Tickets</th>
                            <th>Status</th>
                            <th>Last Active</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {agents.map((agent, index) => (
                            <tr key={index}>
                                <td className={styles.agentCell}>
                                    <span className={styles.avatar}>A</span>
                                    {agent.name}
                                </td>
                                <td>{agent.email}</td>
                                <td>{agent.role}</td>
                                <td>{agent.tickets} tickets</td>
                                <td>
                                    <span
                                        className={`${styles.status} ${agent.status === "Active"
                                            ? styles.active
                                            : agent.status === "Away"
                                                ? styles.away
                                                : styles.inactive
                                            }`}
                                    >
                                        {agent.status}
                                    </span>
                                </td>
                                <td>{agent.lastActive}</td>
                                <td className={styles.actions}>
                                    <button
                                        className={styles.dots}
                                        onClick={() =>
                                            setOpenMenu(openMenu === index ? null : index)
                                        }
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === index && (
                                        <div className={styles.menu}>
                                            <button>Edit</button>
                                            <button>Stats</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default SupportAgents;
