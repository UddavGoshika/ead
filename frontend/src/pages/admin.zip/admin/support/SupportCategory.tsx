import React, { useState } from "react";
import styles from "./SupportCategory.module.css";

type Category = {
    name: string;
    tickets: number;
    agents: number;
    sla: string;
    status: "Active" | "Inactive";
};

const categories: Category[] = [
    { name: "Technical Support", tickets: 45, agents: 3, sla: "24 hours", status: "Active" },
    { name: "Billing Issues", tickets: 32, agents: 2, sla: "48 hours", status: "Active" },
    { name: "Account Problems", tickets: 28, agents: 2, sla: "24 hours", status: "Active" },
    { name: "Feature Requests", tickets: 15, agents: 1, sla: "72 hours", status: "Active" },
    { name: "Bug Reports", tickets: 23, agents: 2, sla: "24 hours", status: "Inactive" },
];

const SupportTicketCategories: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<number | null>(null);

    return (
        <div className={styles.wrapper}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Support Ticket Categories</h2>
                <button className={styles.addBtn}>+ Add Category</button>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Active Tickets</th>
                            <th>Assigned Agents</th>
                            <th>SLA</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {categories.map((c, index) => (
                            <tr key={index}>
                                <td className={styles.category}>
                                    <span className={styles.icon}>📁</span>
                                    {c.name}
                                </td>
                                <td>{c.tickets} tickets</td>
                                <td>{c.agents} agents</td>
                                <td>{c.sla}</td>
                                <td>
                                    <span
                                        className={`${styles.status} ${c.status === "Active" ? styles.active : styles.inactive
                                            }`}
                                    >
                                        {c.status}
                                    </span>
                                </td>
                                <td className={styles.actions}>
                                    <button
                                        className={styles.dots}
                                        onClick={() => setOpenMenu(openMenu === index ? null : index)}
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === index && (
                                        <div className={styles.menu}>
                                            <button>Edit</button>
                                            <button className={styles.delete}>Delete</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default SupportTicketCategories;
