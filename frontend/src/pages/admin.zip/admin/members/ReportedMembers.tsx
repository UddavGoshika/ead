import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "R-4001",
        name: "Elijah Mikaelson",
        phone: "9000000006",
        gender: "Male",
        verified: true,
        reported: 15,
        plan: "Gold",
        since: "12-07-2025",
        status: "Active",
        image: "/avatar12.jpg",
    },
];

const ReportedMembers: React.FC = () => {
    return <MemberTable title="Reported Members" initialMembers={members} />;
};

export default ReportedMembers;