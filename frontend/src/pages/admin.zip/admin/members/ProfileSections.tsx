import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const profiles: Member[] = [
    {
        id: 1,
        code: "SEC-01",
        name: "Basic Information",
        phone: "System Section",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "All",
        since: "N/A",
        status: "Active",
        image: "/section_icon.png",
    },
    {
        id: 2,
        code: "SEC-02",
        name: "Professional Details",
        phone: "System Section",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "All",
        since: "N/A",
        status: "Active",
        image: "/section_icon.png",
    }
];

const ProfileSections: React.FC = () => {
    return <MemberTable title="Profile Sections" initialMembers={profiles} />;
};

export default ProfileSections;