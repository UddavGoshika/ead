import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "P-9002",
        name: "Stefan Salvatore",
        phone: "9000000002",
        gender: "Male",
        verified: false,
        reported: 0,
        plan: "Pending",
        since: "21-11-2025",
        status: "Pending",
        image: "/avatar8.jpg",
    },
];

const PendingMembers: React.FC = () => {
    return <MemberTable title="Pending Members" initialMembers={members} />;
};

export default PendingMembers;