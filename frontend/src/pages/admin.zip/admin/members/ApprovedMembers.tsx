import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "A-5001",
        name: "Elena Gilbert",
        phone: "9000000001",
        gender: "Female",
        verified: true,
        reported: 0,
        plan: "Free",
        since: "20-11-2025",
        status: "Active",
        image: "/avatar7.jpg",
    },
];

const ApprovedMembers: React.FC = () => {
    return <MemberTable title="Approved Members" initialMembers={members} />;
};

export default ApprovedMembers;