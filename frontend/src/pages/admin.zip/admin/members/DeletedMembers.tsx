import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "DEL-3001",
        name: "Rebekah Mikaelson",
        phone: "9000000005",
        gender: "Female",
        verified: false,
        reported: 0,
        plan: "Free",
        since: "01-08-2025",
        status: "Deleted",
        image: "/avatar11.jpg",
    },
];

const DeletedMembers: React.FC = () => {
    return <MemberTable title="Deleted Members" initialMembers={members} />;
};

export default DeletedMembers;