import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "B-2001",
        name: "Klaus Mikaelson",
        phone: "9000000004",
        gender: "Male",
        verified: true,
        reported: 12,
        plan: "Free",
        since: "05-09-2025",
        status: "Blocked",
        image: "/avatar10.jpg",
    },
];

const BlockedMembers: React.FC = () => {
    return <MemberTable title="Blocked Members" initialMembers={members} />;
};

export default BlockedMembers;