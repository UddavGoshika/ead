import React, { useState } from "react";
import styles from "./BulkMemberAdd.module.css";

const BulkMemberAdd: React.FC = () => {
    const [file, setFile] = useState<File | null>(null);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            setFile(e.target.files[0]);
        }
    };

    const handleUpload = () => {
        if (file) {
            alert(`Uploading ${file.name}...`);
        } else {
            alert("Please select a file first.");
        }
    };

    return (
        <div className={styles.card}>
            <div className={styles.header}>
                <h2>Bulk Member Import</h2>
            </div>

            <div className={styles.instructions}>
                <p>1. Download the template file to see the required format.</p>
                <button className={styles.downloadBtn}>Download Template (.csv)</button>
            </div>

            <div className={styles.uploadSection}>
                <div className={styles.dropZone}>
                    <input
                        type="file"
                        id="bulkFileUpload"
                        className={styles.fileInput}
                        onChange={handleFileChange}
                        accept=".csv, .xlsx"
                    />
                    <label htmlFor="bulkFileUpload" className={styles.fileLabel}>
                        <div className={styles.uploadIcon}>📁</div>
                        <div className={styles.uploadText}>
                            {file ? <strong>{file.name}</strong> : "Click to select or drag and drop your CSV/Excel file"}
                        </div>
                        <div className={styles.uploadMeta}>Max file size: 10MB</div>
                    </label>
                </div>

                <div className={styles.actions}>
                    <button className={styles.uploadBtn} onClick={handleUpload}>
                        Start Import Process
                    </button>
                </div>
            </div>

            <div className={styles.notes}>
                <h4>Important Notes:</h4>
                <ul>
                    <li>The system supports .CSV and .XLSX formats.</li>
                    <li>Ensure the headers match the template exactly.</li>
                    <li>Passwords will be generated automatically if not provided.</li>
                    <li>Members will receive an invitation email upon successful import.</li>
                </ul>
            </div>
        </div>
    );
};

export default BulkMemberAdd;