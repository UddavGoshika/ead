import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const verifications: Member[] = [
    {
        id: 1,
        code: "VER-100",
        name: "Identity Proof",
        phone: "Required",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "Mandatory",
        since: "N/A",
        status: "Active",
        image: "/verify_icon.png",
    }
];

const MemberVerification: React.FC = () => {
    return <MemberTable title="Member Verification Form Config" initialMembers={verifications} />;
};

export default MemberVerification;