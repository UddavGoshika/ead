import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const members: Member[] = [
    {
        id: 1,
        code: "D-1001",
        name: "Damon Salvatore",
        phone: "9000000003",
        gender: "Male",
        verified: true,
        reported: 5,
        plan: "Pro",
        since: "10-10-2025",
        status: "Deactivated",
        image: "/avatar9.jpg",
    },
];

const DeactivatedMembers: React.FC = () => {
    return <MemberTable title="Deactivated Members" initialMembers={members} />;
};

export default DeactivatedMembers;