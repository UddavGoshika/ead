import React from "react";
import styles from "./PaymentMethods.module.css";

const Section = ({
    title,
    children,
}: {
    title: string;
    children: React.ReactNode;
}) => (
    <div className={styles.card}>
        <div className={styles.cardHeader}>
            <h3>{title}</h3>
            <label className={styles.switch}>
                <input type="checkbox" defaultChecked />
                <span className={styles.slider} />
            </label>
        </div>

        <div className={styles.content}>{children}</div>

        <div className={styles.actions}>
            <button className={styles.saveBtn}>Save</button>
        </div>
    </div>
);

const PaymentCredentials: React.FC = () => {
    return (
        <div className={styles.page}>
            {/* PAYPAL */}
            <Section title="Paypal Credential">
                <input placeholder="Paypal Client ID" />
                <input placeholder="Paypal Client Secret" />
                <label className={styles.inlineToggle}>
                    <span>Paypal Sandbox Mode</span>
                    <input type="checkbox" defaultChecked />
                </label>
            </Section>

            {/* INSTAMOJO */}
            <Section title="Instamojo Credential">
                <input placeholder="Instamojo API Key" />
                <input placeholder="Instamojo Auth Token" />
                <label className={styles.inlineToggle}>
                    <span>Instamojo Sandbox Mode</span>
                    <input type="checkbox" />
                </label>
            </Section>

            {/* STRIPE */}
            <Section title="Stripe Credential">
                <input placeholder="Stripe Key" />
                <input placeholder="Stripe Secret" />
            </Section>

            {/* RAZORPAY */}
            <Section title="Razorpay Credential">
                <input placeholder="Razorpay Key" />
                <input placeholder="Razorpay Secret" />
            </Section>

            {/* PAYTM */}
            <Section title="Paytm Credential">
                <select>
                    <option>Production</option>
                    <option>Sandbox</option>
                </select>
                <input placeholder="Paytm Merchant ID" />
                <input placeholder="Paytm Merchant Key" />
                <input placeholder="Paytm Merchant Website" />
                <input placeholder="Paytm Channel" />
                <input placeholder="Paytm Industry Type" />
            </Section>

            {/* PAYSTACK */}
            <Section title="Paystack Credential">
                <input placeholder="Public Key" />
                <input placeholder="Secret Key" />
                <input placeholder="Merchant Email" />
                <input placeholder="Paystack Currency Code" />
            </Section>

            {/* AAMARPAY */}
            <Section title="Aamarpay Credential">
                <input placeholder="Aamarpay Store ID" />
                <input placeholder="Aamarpay Signature Key" />
                <label className={styles.inlineToggle}>
                    <span>Aamarpay Sandbox Mode</span>
                    <input type="checkbox" />
                </label>
            </Section>

            {/* SSL COMMERZ */}
            <Section title="Sslcommerz Credential">
                <input placeholder="Store ID" />
                <input placeholder="Store Password" />
                <label className={styles.inlineToggle}>
                    <span>Sslcommerz Sandbox Mode</span>
                    <input type="checkbox" defaultChecked />
                </label>
            </Section>

            {/* PHONEPE */}
            <Section title="Phonepe">
                <div className={styles.radioRow}>
                    <label>
                        <input type="radio" name="phonepe" defaultChecked /> v1
                    </label>
                    <label>
                        <input type="radio" name="phonepe" /> v2
                    </label>
                </div>
                <input placeholder="Phonepe Merchant ID" />
                <input placeholder="Phonepe Salt Key" />
                <input placeholder="Phonepe Salt Index" />
                <label className={styles.inlineToggle}>
                    <span>Phonepe Sandbox Mode</span>
                    <input type="checkbox" defaultChecked />
                </label>
            </Section>
        </div>
    );
};

export default PaymentCredentials;
