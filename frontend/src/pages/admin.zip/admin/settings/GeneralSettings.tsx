import React from "react";
import styles from "./GeneralSettings.module.css";

const GeneralSettings: React.FC = () => {
    return (
        <div className={styles.page}>
            {/* GENERAL SETTINGS */}
            <div className={styles.card}>
                <h3 className={styles.title}>General Settings</h3>

                <div className={styles.form}>
                    <div className={styles.field}>
                        <label>System Name</label>
                        <input type="text" defaultValue="Active Matrimonial" />
                    </div>

                    <div className={styles.field}>
                        <label>System Logo</label>
                        <input type="file" />
                    </div>

                    <div className={styles.field}>
                        <label>System Timezone</label>
                        <select>
                            <option>(GMT+05:30) New Delhi</option>
                        </select>
                    </div>

                    <div className={styles.field}>
                        <label>Admin Login Page Background</label>
                        <input type="file" />
                    </div>

                    <div className={styles.field}>
                        <label>Member Code Prefix</label>
                        <input type="text" defaultValue="AMC" />
                    </div>

                    <div className={styles.field}>
                        <label>Male Member Minimum Age</label>
                        <input type="number" defaultValue={21} />
                    </div>

                    <div className={styles.field}>
                        <label>Female Member Minimum Age</label>
                        <input type="number" defaultValue={19} />
                    </div>

                    <div className={styles.field}>
                        <label>Member Profile Picture Privacy</label>
                        <select>
                            <option>All</option>
                            <option>Premium Members</option>
                        </select>
                    </div>

                    <div className={styles.field}>
                        <label>Member Gallery Image Privacy</label>
                        <select>
                            <option>All</option>
                            <option>Premium Members</option>
                        </select>
                    </div>
                </div>

                <div className={styles.actions}>
                    <button className={styles.updateBtn}>Update</button>
                </div>
            </div>

            {/* ACTIVATION */}
            <div className={styles.card}>
                <h3 className={styles.title}>Activation</h3>

                <div className={styles.toggleList}>
                    <Toggle label="HTTPS Activation" />
                    <Toggle label="Maintenance Mode Activation" />
                    <Toggle label="Wallet System Activation" active />
                    <Toggle
                        label="Email/Phone Verification"
                        note="You need to configure SMTP correctly"
                    />
                    <Toggle label="Registration Verification" active />
                    <Toggle label="Member Verification" active />
                    <Toggle
                        label="Only Premium Member Can See Other Members Full Profile"
                        active
                    />
                    <Toggle
                        label="Member Profile Picture Approval by Admin"
                    />
                    <Toggle label="Disable Image Encoding?" active />
                </div>
            </div>
        </div>
    );
};

const Toggle = ({
    label,
    active,
    note,
}: {
    label: string;
    active?: boolean;
    note?: string;
}) => (
    <div className={styles.toggleRow}>
        <div>
            <span>{label}</span>
            {note && <small>{note}</small>}
        </div>
        <label className={styles.switch}>
            <input type="checkbox" defaultChecked={active} />
            <span className={styles.slider} />
        </label>
    </div>
);

export default GeneralSettings;
