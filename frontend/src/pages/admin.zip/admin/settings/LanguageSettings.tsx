import React from "react";
import styles from "./LanguageSettings.module.css";

type Language = {
    id: number;
    name: string;
    code: string;
    rtl: boolean;
};

const languages: Language[] = [
    { id: 1, name: "English", code: "en", rtl: false },
    { id: 2, name: "Bangla", code: "bd", rtl: false },
];

const LanguageSettings: React.FC = () => {
    return (
        <div className={styles.page}>
            {/* DEFAULT LANGUAGE */}
            <div className={styles.card}>
                <h3>Default Language</h3>
                <div className={styles.inline}>
                    <select>
                        <option>English</option>
                        <option>Bangla</option>
                    </select>
                    <button className={styles.saveBtn}>Save</button>
                </div>
            </div>

            {/* GRID */}
            <div className={styles.grid}>
                {/* ALL LANGUAGES */}
                <div className={styles.card}>
                    <h3>All Languages</h3>

                    <table className={styles.table}>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Code</th>
                                <th>RTL</th>
                                <th>Options</th>
                            </tr>
                        </thead>

                        <tbody>
                            {languages.map((l) => (
                                <tr key={l.id}>
                                    <td>{l.id}</td>
                                    <td>{l.name}</td>
                                    <td>{l.code}</td>
                                    <td>
                                        <label className={styles.switch}>
                                            <input type="checkbox" defaultChecked={l.rtl} />
                                            <span className={styles.slider} />
                                        </label>
                                    </td>
                                    <td className={styles.options}>
                                        <button className={styles.iconEdit}>✎</button>
                                        <button className={styles.iconTranslate}>🌐</button>
                                        {l.id !== 1 && (
                                            <button className={styles.iconDelete}>🗑</button>
                                        )}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* ADD NEW LANGUAGE */}
                <div className={styles.card}>
                    <h3>Add New Language</h3>

                    <div className={styles.field}>
                        <label>Name</label>
                        <input placeholder="Eg. English" />
                    </div>

                    <div className={styles.field}>
                        <label>Code</label>
                        <select>
                            <option>AD</option>
                            <option>EN</option>
                            <option>BD</option>
                        </select>
                    </div>

                    <div className={styles.right}>
                        <button className={styles.saveBtn}>Save</button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default LanguageSettings;
