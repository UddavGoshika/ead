import React from 'react';
import styles from './Newsletter.module.css';

const Newsletter: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Newsletter</h1>
            <p>Welcome to the Newsletter management module.</p>
        </div>
    );
};

export default Newsletter;