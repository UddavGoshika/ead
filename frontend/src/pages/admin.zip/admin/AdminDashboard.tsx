import React, { useMemo, useState } from "react";
import styles from "./admindash.module.css";
import RevenueChart from "./revenuechart";

/* ================= TYPES ================= */
type VerificationStatus = "Approved" | "Pending";
type MemberStatus = "Active" | "Blocked" | "Deactivated";
type StatusType = "verified" | "pending" | "blocked" | "deactivated";

interface Member {
    id: number;
    image: string;
    memberCode: string;
    name: string;
    phone: string;
    gender: string;
    verificationStatus: VerificationStatus;
    reported: number;
    memberSince: string;
    status: MemberStatus;
}

type StatusBreakdown = {
    verified: number;
    pending: number;
    blocked: number;
    deactivated: number;
};

type TierStats = {
    advocates: StatusBreakdown;
    clients: StatusBreakdown;
};

type PlanStats = {
    [tier: string]: TierStats;
};

/* ================= PREMIUM DATA ================= */
const premiumStats: Record<string, PlanStats> = {
    Free: {
        Silver: {
            advocates: { verified: 40, pending: 10, blocked: 2, deactivated: 3 },
            clients: { verified: 120, pending: 20, blocked: 5, deactivated: 6 },
        },
        Gold: {
            advocates: { verified: 60, pending: 8, blocked: 1, deactivated: 2 },
            clients: { verified: 180, pending: 15, blocked: 3, deactivated: 4 },
        },
        Platinum: {
            advocates: { verified: 80, pending: 5, blocked: 1, deactivated: 1 },
            clients: { verified: 250, pending: 10, blocked: 2, deactivated: 3 },
        },
    },
    "Pro Lite": {
        Silver: {
            advocates: { verified: 50, pending: 8, blocked: 1, deactivated: 2 },
            clients: { verified: 160, pending: 14, blocked: 3, deactivated: 5 },
        },
        Gold: {
            advocates: { verified: 70, pending: 6, blocked: 1, deactivated: 1 },
            clients: { verified: 220, pending: 10, blocked: 2, deactivated: 3 },
        },
        Platinum: {
            advocates: { verified: 90, pending: 4, blocked: 0, deactivated: 1 },
            clients: { verified: 300, pending: 8, blocked: 1, deactivated: 2 },
        },
    },
    Pro: {
        Silver: {
            advocates: { verified: 65, pending: 7, blocked: 2, deactivated: 1 },
            clients: { verified: 200, pending: 12, blocked: 4, deactivated: 6 },
        },
        Gold: {
            advocates: { verified: 85, pending: 5, blocked: 1, deactivated: 1 },
            clients: { verified: 280, pending: 9, blocked: 2, deactivated: 3 },
        },
        Platinum: {
            advocates: { verified: 110, pending: 3, blocked: 0, deactivated: 1 },
            clients: { verified: 360, pending: 6, blocked: 1, deactivated: 2 },
        },
    },
    "Ultimate Pro": {
        Platinum: {
            advocates: { verified: 150, pending: 2, blocked: 0, deactivated: 0 },
            clients: { verified: 500, pending: 4, blocked: 1, deactivated: 1 },
        },
    },
};

/* ================= MEMBERS ================= */
const members: Member[] = [
    {
        id: 1,
        image: "https://randomuser.me/api/portraits/men/1.jpg",
        memberCode: "20250525",
        name: "Arhaan Malik",
        phone: "123445",
        gender: "Male",
        verificationStatus: "Approved",
        reported: 0,
        memberSince: "13-05-2025",
        status: "Active",
    },
    {
        id: 2,
        image: "https://randomuser.me/api/portraits/men/2.jpg",
        memberCode: "20250517",
        name: "Henry Lawson",
        phone: "123445",
        gender: "Male",
        verificationStatus: "Approved",
        reported: 0,
        memberSince: "13-05-2025",
        status: "Active",
    },
    {
        id: 3,
        image: "https://randomuser.me/api/portraits/women/3.jpg",
        memberCode: "20250513",
        name: "Emma Watson",
        phone: "123445",
        gender: "Female",
        verificationStatus: "Approved",
        reported: 0,
        memberSince: "13-05-2025",
        status: "Active",
    },
    {
        id: 4,
        image: "https://randomuser.me/api/portraits/men/4.jpg",
        memberCode: "20250514",
        name: "Adrian Cole",
        phone: "123445",
        gender: "Male",
        verificationStatus: "Approved",
        reported: 0,
        memberSince: "13-05-2025",
        status: "Deactivated",
    },
];

/* ================= STATUS PILL ================= */
const StatusPill = ({
    label,
    value,
    type,
}: {
    label: string;
    value: number;
    type: StatusType;
}) => (
    <span className={`${styles.pill} ${styles[type]}`}>
        {label}: {value}
        <span className={styles.tooltip}>{label} users</span>
    </span>
);

/* ================= COMPONENT ================= */
const AdminDashboard: React.FC = () => {
    const [expanded, setExpanded] = useState<Record<string, boolean>>({});

    const stats = useMemo(() => ({
        total: members.length,
        verified: members.filter(m => m.verificationStatus === "Approved").length,
        pending: members.filter(m => m.verificationStatus === "Pending").length,
        blocked: members.filter(m => m.status === "Blocked").length,
        deactivated: members.filter(m => m.status === "Deactivated").length,
    }), []);

    const toggle = (key: string) =>
        setExpanded(prev => ({ ...prev, [key]: !prev[key] }));

    return (
        <div className={styles.dashboard}>

            <header className={styles.header}>
                <h1>Admin Dashboard Overview</h1>
                <p>Welcome back! Here's what's happening today.</p>
            </header>

            {/* ================= TOP SECTION ================= */}
            <section className={styles.topSection}>
                {/* GRAPH */}
                <div className={styles.graphCard}>
                    <RevenueChart />
                </div>

                {/* RIGHT STATS */}
                <div className={styles.rightStats}>
                    <div className={styles.statBox}>
                        <h4>Total Advocates</h4>
                        <p>2,540</p>
                    </div>
                    <div className={styles.statBox}>
                        <h4>Total Clients</h4>
                        <p>8,920</p>
                    </div>
                    <div className={styles.statBox}>
                        <h4>Total Users</h4>
                        <p>11,460</p>
                    </div>
                </div>
            </section>




            {/* ================= PREMIUM ================= */}
            <section className={styles.detailSection}>
                <h2>Premium Services – Detailed View</h2>

                <div className={styles.planGrid}>
                    {Object.entries(premiumStats).map(([plan, tiers]) => (
                        <div key={plan} className={styles.planCard}>
                            <h3>{plan}</h3>

                            {Object.entries(tiers).map(([tier, data]) => {
                                const key = `${plan}-${tier}`;
                                const advTotal = Object.values(data.advocates).reduce((a, b) => a + b, 0);
                                const cliTotal = Object.values(data.clients).reduce((a, b) => a + b, 0);

                                return (
                                    <div key={tier} className={styles.tierRow}>
                                        <div className={styles.tierHeader} onClick={() => toggle(key)}>
                                            <span>{tier}</span>
                                            <span>{expanded[key] ? "−" : "+"}</span>
                                        </div>

                                        {expanded[key] && (
                                            <div className={styles.threeGrid}>
                                                <div className={styles.statGroup}>
                                                    <h4>Advocates</h4>
                                                    <StatusPill label="Verified" value={data.advocates.verified} type="verified" />
                                                    <StatusPill label="Pending" value={data.advocates.pending} type="pending" />
                                                    <StatusPill label="Blocked" value={data.advocates.blocked} type="blocked" />
                                                    <StatusPill label="Deactivated" value={data.advocates.deactivated} type="deactivated" />
                                                    <strong>Total: {advTotal}</strong>
                                                </div>

                                                <div className={styles.statGroup}>
                                                    <h4>Clients</h4>
                                                    <StatusPill label="Verified" value={data.clients.verified} type="verified" />
                                                    <StatusPill label="Pending" value={data.clients.pending} type="pending" />
                                                    <StatusPill label="Blocked" value={data.clients.blocked} type="blocked" />
                                                    <StatusPill label="Deactivated" value={data.clients.deactivated} type="deactivated" />
                                                    <strong>Total: {cliTotal}</strong>
                                                </div>

                                                <div className={styles.statGroup}>
                                                    <h4>Overall</h4>
                                                    <p>Advocates: {advTotal}</p>
                                                    <p>Clients: {cliTotal}</p>
                                                    <strong>Total Users: {advTotal + cliTotal}</strong>
                                                </div>
                                            </div>
                                        )}
                                    </div>
                                );
                            })}
                        </div>
                    ))}
                </div>
            </section>



            {/* ================= MEMBERS LIST ================= */}
            <div className={styles.container}>
                <div className={styles.header}>
                    <h1>All Members</h1>
                    <input
                        className={styles.search}
                        placeholder="Type first name / last name / Phone / ID & Enter"
                    />
                </div>

                <div className={styles.summaryGrid}>
                    <div className={styles.summaryCard}>
                        <h3>Total Members</h3>
                        <p>{stats.total}</p>
                    </div>
                    <div className={styles.summaryCard}>
                        <h3>Verified</h3>
                        <p className={styles.green}>{stats.verified}</p>
                    </div>
                    <div className={styles.summaryCard}>
                        <h3>Pending</h3>
                        <p className={styles.orange}>{stats.pending}</p>
                    </div>
                    <div className={styles.summaryCard}>
                        <h3>Blocked</h3>
                        <p className={styles.red}>{stats.blocked}</p>
                    </div>
                    <div className={styles.summaryCard}>
                        <h3>Deactivated</h3>
                        <p className={styles.gray}>{stats.deactivated}</p>
                    </div>
                </div>

                <div className={styles.tableWrapper}>
                    <table className={styles.table}>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Image</th>
                                <th>Member Code</th>
                                <th>Name / Phone</th>
                                <th>Gender</th>
                                <th>Verification Status</th>
                                <th>Profile Reported</th>
                                <th>Member Since</th>
                                <th>Member Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>

                        <tbody>
                            {members.map((m, index) => (
                                <tr key={m.id}>
                                    <td>{index + 1}</td>
                                    <td>
                                        <img src={m.image} className={styles.avatar} />
                                    </td>
                                    <td>{m.memberCode}</td>
                                    <td>
                                        <strong>{m.name}</strong>
                                        <div className={styles.phone}>{m.phone}</div>
                                    </td>
                                    <td>{m.gender}</td>
                                    <td>
                                        <span className={`${styles.badge} ${styles.approved}`}>
                                            {m.verificationStatus}
                                        </span>
                                    </td>
                                    <td>{m.reported}</td>
                                    <td>{m.memberSince}</td>
                                    <td>
                                        <span
                                            className={`${styles.badge} ${m.status === "Active"
                                                ? styles.active
                                                : m.status === "Blocked"
                                                    ? styles.blocked
                                                    : styles.deactivated
                                                }`}
                                        >
                                            {m.status}
                                        </span>
                                    </td>
                                    <td>
                                        <button className={styles.actionButton}>⋮</button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>


        </div>
    );
};

export default AdminDashboard;
