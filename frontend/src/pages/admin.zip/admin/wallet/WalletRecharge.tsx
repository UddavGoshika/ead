import React, { useState } from "react";
import styles from "./WalletRecharge.module.css";

type Status = "Pending" | "Approved" | "Rejected";

type Request = {
    id: string;
    user: string;
    amount: string;
    method: string;
    date: string;
    status: Status;
};

const requests: Request[] = [
    {
        id: "REQ001",
        user: "John Smith",
        amount: "$100",
        method: "Bank Transfer",
        date: "2024-01-15",
        status: "Pending",
    },
    {
        id: "REQ002",
        user: "Emma Johnson",
        amount: "$50",
        method: "Cash Deposit",
        date: "2024-01-14",
        status: "Approved",
    },
    {
        id: "REQ003",
        user: "Michael Brown",
        amount: "$200",
        method: "Bank Transfer",
        date: "2024-01-13",
        status: "Pending",
    },
    {
        id: "REQ004",
        user: "Sarah Davis",
        amount: "$75",
        method: "Cheque",
        date: "2024-01-12",
        status: "Rejected",
    },
    {
        id: "REQ005",
        user: "Robert Wilson",
        amount: "$150",
        method: "Bank Transfer",
        date: "2024-01-11",
        status: "Approved",
    },
];

const ManualWalletRecharge: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<string | null>(null);

    return (
        <div className={styles.page}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Manual Wallet Recharge Requests</h2>
                <button className={styles.addBtn}>+ Add Method</button>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Submitted Date</th>
                            <th>Proof Document</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {requests.map((r) => (
                            <tr key={r.id}>
                                <td className={styles.id}>{r.id}</td>
                                <td>{r.user}</td>
                                <td className={styles.amount}>{r.amount}</td>
                                <td>{r.method}</td>
                                <td>{r.date}</td>
                                <td>
                                    <button className={styles.proofBtn}>View Proof</button>
                                </td>
                                <td>
                                    <span
                                        className={`${styles.status} ${styles[r.status.toLowerCase()]
                                            }`}
                                    >
                                        {r.status}
                                    </span>
                                </td>
                                <td className={styles.actions}>
                                    <button
                                        className={styles.menuBtn}
                                        onClick={() =>
                                            setOpenMenu(openMenu === r.id ? null : r.id)
                                        }
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === r.id && (
                                        <div className={styles.menu}>
                                            {r.status === "Pending" && (
                                                <>
                                                    <button className={styles.approve}>Approve</button>
                                                    <button className={styles.reject}>Reject</button>
                                                </>
                                            )}
                                            <button className={styles.details}>Details</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* BOTTOM CARDS */}
            <div className={styles.bottomGrid}>
                <div className={styles.card}>
                    <h3>Available Payment Methods</h3>
                    <div className={styles.methods}>
                        <div>
                            <strong>Bank Transfer</strong>
                            <p>Account details for manual transfers</p>
                            <button className={styles.configBtn}>Configure</button>
                        </div>
                        <div>
                            <strong>Cash Deposit</strong>
                            <p>Physical cash deposit instructions</p>
                            <button className={styles.configBtn}>Configure</button>
                        </div>
                    </div>
                </div>

                <div className={styles.card}>
                    <h3>Recharge Statistics</h3>
                    <div className={styles.stats}>
                        <div>
                            <span className={styles.big}>$200</span>
                            <p>Total Approved</p>
                        </div>
                        <div>
                            <span className={styles.big}>2</span>
                            <p>Pending Requests</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ManualWalletRecharge;
