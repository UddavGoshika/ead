import React from "react";
import styles from "./WalletHistory.module.css";

type WalletTx = {
    id: number;
    member: string;
    date: string;
    amount: string;
    method: string;
    approval: string;
};

const data: WalletTx[] = [
    {
        id: 1,
        member: "Haria Mary",
        date: "13-07-2025",
        amount: "10.00$",
        method: "Referred commission",
        approval: "N/A",
    },
    {
        id: 2,
        member: "Elizabeth Liza",
        date: "16-05-2025",
        amount: "100.00$",
        method: "Added by admin",
        approval: "N/A",
    },
    {
        id: 3,
        member: "Elizabeth Liza",
        date: "16-05-2025",
        amount: "100.00$",
        method: "Added by admin",
        approval: "N/A",
    },
    {
        id: 4,
        member: "Emma Watson",
        date: "16-05-2025",
        amount: "100.00$",
        method: "Added by admin",
        approval: "N/A",
    },
];

const WalletHistory: React.FC = () => {
    return (
        <div className={styles.page}>
            <h2 className={styles.pageTitle}>Wallet Transaction History</h2>

            <div className={styles.card}>
                {/* HEADER / FILTERS */}
                <div className={styles.header}>
                    <h3>Wallet History</h3>

                    <div className={styles.filters}>
                        <select>
                            <option>Choose User</option>
                            <option>Haria Mary</option>
                            <option>Elizabeth Liza</option>
                            <option>Emma Watson</option>
                        </select>

                        <input type="text" placeholder="Daterange" />

                        <button className={styles.filterBtn}>Filter</button>
                    </div>
                </div>

                {/* TABLE */}
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Member</th>
                            <th>Date</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Approval</th>
                        </tr>
                    </thead>

                    <tbody>
                        {data.map((tx) => (
                            <tr key={tx.id}>
                                <td>{tx.id}</td>
                                <td>{tx.member}</td>
                                <td>{tx.date}</td>
                                <td className={styles.amount}>{tx.amount}</td>
                                <td>{tx.method}</td>
                                <td>{tx.approval}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default WalletHistory;
