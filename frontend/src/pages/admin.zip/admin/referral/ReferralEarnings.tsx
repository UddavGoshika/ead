import React from "react";
import styles from "./ReferralEarnings.module.css";

type ReportRow = {
    month: string;
    totalReferrals: number;
    successfulReferrals: number;
    totalCommission: string;
    paidCommission: string;
    pendingCommission: string;
};

const reportData: ReportRow[] = [
    {
        month: "Dec",
        totalReferrals: 17,
        successfulReferrals: 6,
        totalCommission: "$1024.28",
        paidCommission: "$345.89",
        pendingCommission: "$349.86",
    },
    {
        month: "Jan",
        totalReferrals: 9,
        successfulReferrals: 4,
        totalCommission: "$356.82",
        paidCommission: "$192.39",
        pendingCommission: "$83.56",
    },
    {
        month: "Nov",
        totalReferrals: 4,
        successfulReferrals: 1,
        totalCommission: "$292.84",
        paidCommission: "$72.16",
        pendingCommission: "$168.09",
    },
];

const ReferralEarningsReport: React.FC = () => {
    return (
        <div className={styles.wrapper}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Referral Earnings Report</h2>

                <div className={styles.headerActions}>
                    <button className={styles.exportBtn}>📤 Export Report</button>
                    <select className={styles.select}>
                        <option>Last 30 Days</option>
                        <option>Last 60 Days</option>
                        <option>Last Year</option>
                    </select>
                </div>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Total Referrals</th>
                            <th>Successful Referrals</th>
                            <th>Total Commission</th>
                            <th>Paid Commission</th>
                            <th>Pending Commission</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {reportData.map((row, index) => (
                            <tr key={index}>
                                <td className={styles.month}>{row.month}</td>
                                <td>{row.totalReferrals}</td>
                                <td>{row.successfulReferrals}</td>
                                <td className={styles.money}>{row.totalCommission}</td>
                                <td className={styles.money}>{row.paidCommission}</td>
                                <td className={styles.money}>{row.pendingCommission}</td>
                                <td>
                                    <button className={styles.detailsBtn}>Details</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* SUMMARY */}
            <div className={styles.summary}>
                <div className={styles.stat}>
                    <h3>$1673.94</h3>
                    <span>Total Commission</span>
                </div>
                <div className={styles.stat}>
                    <h3>$610.44</h3>
                    <span>Paid Out</span>
                </div>
                <div className={styles.stat}>
                    <h3>$601.51</h3>
                    <span>Pending Payout</span>
                </div>
                <div className={styles.stat}>
                    <h3>30</h3>
                    <span>Total Referrals</span>
                </div>
            </div>
        </div>
    );
};

export default ReferralEarningsReport;
