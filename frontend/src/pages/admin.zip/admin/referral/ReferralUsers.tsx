import React, { useState } from "react";
import styles from "./ReferralUsers.module.css";

/* ================= TYPES ================= */
type UserStatus = "active" | "blocked";

interface Wallet {
    earned: number;
    withdrawn: number;
    pending: number;
}

interface ReferralUser {
    id: string;
    name: string;
    level: number;
    status: UserStatus;
    wallet: Wallet;
    joinedAt: string;
    children?: ReferralUser[];
}

/* ================= MOCK DATA ================= */
const referralTree: ReferralUser = {
    id: "U100",
    name: "B Person (Root User)",
    level: 0,
    status: "active",
    joinedAt: "2024-01-01",
    wallet: { earned: 1200, withdrawn: 700, pending: 500 },
    children: [
        {
            id: "U101",
            name: "A Person",
            level: 1,
            status: "active",
            joinedAt: "2024-01-10",
            wallet: { earned: 400, withdrawn: 200, pending: 200 },
            children: [
                {
                    id: "U102",
                    name: "C Person",
                    level: 2,
                    status: "active",
                    joinedAt: "2024-01-15",
                    wallet: { earned: 120, withdrawn: 50, pending: 70 },
                },
                {
                    id: "U103",
                    name: "D Person",
                    level: 2,
                    status: "blocked",
                    joinedAt: "2024-01-18",
                    wallet: { earned: 90, withdrawn: 30, pending: 60 },
                },
            ],
        },
        {
            id: "U104",
            name: "E Person",
            level: 1,
            status: "active",
            joinedAt: "2024-01-12",
            wallet: { earned: 300, withdrawn: 120, pending: 180 },
        },
    ],
};

/* ================= TREE NODE ================= */
const ReferralNode: React.FC<{ user: ReferralUser }> = ({ user }) => {
    const [open, setOpen] = useState(true);

    return (
        <div className={styles.nodeWrapper}>
            <div className={styles.nodeRow}>
                <button
                    className={styles.expandBtn}
                    onClick={() => setOpen(!open)}
                >
                    {user.children ? (open ? "−" : "+") : "•"}
                </button>

                <div className={styles.userCard}>
                    <div className={styles.userHeader}>
                        <div>
                            <h4>{user.name}</h4>
                            <span className={styles.meta}>
                                ID: {user.id} · Level {user.level}
                            </span>
                        </div>

                        <span
                            className={`${styles.status} ${user.status === "active"
                                ? styles.active
                                : styles.blocked
                                }`}
                        >
                            {user.status}
                        </span>
                    </div>

                    <div className={styles.walletGrid}>
                        <div>
                            <label>Earned</label>
                            <span className={styles.earned}>₹{user.wallet.earned}</span>
                        </div>
                        <div>
                            <label>Withdrawn</label>
                            <span className={styles.withdrawn}>
                                ₹{user.wallet.withdrawn}
                            </span>
                        </div>
                        <div>
                            <label>Pending</label>
                            <span className={styles.pending}>
                                ₹{user.wallet.pending}
                            </span>
                        </div>
                    </div>

                    <div className={styles.joined}>
                        Joined: {user.joinedAt}
                    </div>
                </div>
            </div>

            {open && user.children && (
                <div className={styles.children}>
                    {user.children.map(child => (
                        <ReferralNode key={child.id} user={child} />
                    ))}
                </div>
            )}
        </div>
    );
};

/* ================= MAIN COMPONENT ================= */
const ReferralUserAdmin: React.FC = () => {
    return (
        <div className={styles.container}>
            {/* HEADER */}
            <header className={styles.header}>
                <h1>Referral Chain System</h1>
                <p>Super Admin – Who Joined Through Whom</p>
            </header>

            {/* SUMMARY */}
            <section className={styles.summary}>
                <div className={styles.summaryCard}>
                    <h3>Total Users</h3>
                    <span>6</span>
                </div>
                <div className={styles.summaryCard}>
                    <h3>Total Earned</h3>
                    <span className={styles.earned}>₹2,110</span>
                </div>
                <div className={styles.summaryCard}>
                    <h3>Total Withdrawn</h3>
                    <span className={styles.withdrawn}>₹1,100</span>
                </div>
                <div className={styles.summaryCard}>
                    <h3>Pending</h3>
                    <span className={styles.pending}>₹1,010</span>
                </div>
            </section>

            {/* TREE */}
            <section className={styles.treeSection}>
                <h2>Referral Hierarchy</h2>
                <ReferralNode user={referralTree} />
            </section>
        </div>
    );
};

export default ReferralUserAdmin;
