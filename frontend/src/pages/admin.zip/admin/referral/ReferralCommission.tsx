import React from "react";
import styles from "./ReferralCommission.module.css";

type CommissionRule = {
    level: string;
    type: string;
    value: string;
    condition: string;
    status: "Active" | "Inactive";
};

const rules: CommissionRule[] = [
    {
        level: "Level 1",
        type: "Percentage",
        value: "10%",
        condition: "On first payment",
        status: "Active",
    },
    {
        level: "Level 2",
        type: "Percentage",
        value: "5%",
        condition: "On second payment",
        status: "Active",
    },
    {
        level: "Level 3",
        type: "Fixed",
        value: "$5",
        condition: "Per referral",
        status: "Active",
    },
    {
        level: "Premium Bonus",
        type: "Percentage",
        value: "15%",
        condition: "Premium signup",
        status: "Active",
    },
    {
        level: "Enterprise Bonus",
        type: "Fixed",
        value: "$25",
        condition: "Enterprise signup",
        status: "Inactive",
    },
];

const ReferralCommissionSettings: React.FC = () => {
    return (
        <div className={styles.wrapper}>
            {/* SETTINGS TABLE */}
            <div className={styles.card}>
                <div className={styles.cardHeader}>
                    <h2>Referral Commission Settings</h2>
                    <button className={styles.primaryBtn}>＋ Add Rule</button>
                </div>

                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Commission Level</th>
                            <th>Type</th>
                            <th>Value</th>
                            <th>Condition</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {rules.map((rule, index) => (
                            <tr key={index}>
                                <td className={styles.level}>{rule.level}</td>
                                <td>{rule.type}</td>
                                <td>
                                    <span className={styles.value}>{rule.value}</span>
                                </td>
                                <td>{rule.condition}</td>
                                <td>
                                    <span
                                        className={`${styles.status} ${rule.status === "Active"
                                            ? styles.active
                                            : styles.inactive
                                            }`}
                                    >
                                        {rule.status}
                                    </span>
                                </td>
                                <td className={styles.actions}>
                                    <button className={styles.editBtn}>Edit</button>
                                    <button className={styles.deleteBtn}>Delete</button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {/* CONFIGURATION */}
            <div className={styles.card}>
                <h2>Commission Configuration</h2>

                <div className={styles.formGrid}>
                    <div className={styles.field}>
                        <label>Minimum Payout Amount</label>
                        <input type="number" defaultValue={20} />
                    </div>

                    <div className={styles.field}>
                        <label>Payout Method</label>
                        <select>
                            <option>Bank Transfer</option>
                            <option>PayPal</option>
                            <option>Wallet</option>
                        </select>
                    </div>

                    <div className={styles.fieldFull}>
                        <label>Referral Link Expiry (Days)</label>
                        <input type="number" defaultValue={30} />
                    </div>

                    <div className={styles.checkbox}>
                        <input type="checkbox" defaultChecked />
                        <span>Enable Multi-level Commission</span>
                    </div>
                </div>

                <button className={styles.saveBtn}>Save Settings</button>
            </div>
        </div>
    );
};

export default ReferralCommissionSettings;
