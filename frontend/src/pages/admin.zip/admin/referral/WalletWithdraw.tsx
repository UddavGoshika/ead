import React, { useState } from "react";
import styles from "./WalletWithdraw.module.css";

type Status = "Pending" | "Approved" | "Rejected";

type Request = {
    id: string;
    user: string;
    amount: number;
    method: string;
    account: string;
    date: string;
    status: Status;

    // NEW FIELDS
    earned: number;
    debited: number;
    pending: number;
};

const requests: Request[] = [
    {
        id: "WDR001",
        user: "John Smith",
        amount: 50,
        method: "PayPal",
        account: "john@paypal.com",
        date: "2024-01-15",
        status: "Pending",
        earned: 320,
        debited: 150,
        pending: 170,
    },
    {
        id: "WDR002",
        user: "Emma Johnson",
        amount: 75,
        method: "Bank Transfer",
        account: "****1234",
        date: "2024-01-14",
        status: "Approved",
        earned: 500,
        debited: 425,
        pending: 75,
    },
    {
        id: "WDR003",
        user: "Michael Brown",
        amount: 100,
        method: "Wallet Credit",
        account: "user_wallet",
        date: "2024-01-13",
        status: "Rejected",
        earned: 260,
        debited: 160,
        pending: 100,
    },
    {
        id: "WDR004",
        user: "Sarah Davis",
        amount: 60,
        method: "PayPal",
        account: "sarah@paypal.com",
        date: "2024-01-12",
        status: "Pending",
        earned: 410,
        debited: 200,
        pending: 210,
    },
    {
        id: "WDR005",
        user: "Robert Wilson",
        amount: 120,
        method: "Bank Transfer",
        account: "****5678",
        date: "2024-01-11",
        status: "Approved",
        earned: 680,
        debited: 560,
        pending: 120,
    },
];

const WithdrawalRequests: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<number | null>(null);

    return (
        <div className={styles.wrapper}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Withdrawal Requests</h2>
                <button className={styles.bulkBtn}>⚡ Bulk Process</button>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Request ID</th>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Earned</th>
                            <th>Debited</th>
                            <th>Pending</th>
                            <th>Payment Method</th>
                            <th>Account</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {requests.map((r, index) => (
                            <tr key={r.id}>
                                <td>{r.id}</td>
                                <td>{r.user}</td>
                                <td className={styles.amount}>${r.amount}</td>

                                {/* NEW FINANCIAL INFO */}
                                <td className={styles.earned}>${r.earned}</td>
                                <td className={styles.debited}>${r.debited}</td>
                                <td className={styles.pendingAmt}>${r.pending}</td>

                                <td>{r.method}</td>
                                <td className={styles.mono}>{r.account}</td>
                                <td>{r.date}</td>

                                <td>
                                    <span
                                        className={`${styles.status} ${r.status === "Approved"
                                                ? styles.approved
                                                : r.status === "Rejected"
                                                    ? styles.rejected
                                                    : styles.pending
                                            }`}
                                    >
                                        {r.status}
                                    </span>
                                </td>

                                <td className={styles.actions}>
                                    <button
                                        className={styles.dots}
                                        onClick={() =>
                                            setOpenMenu(openMenu === index ? null : index)
                                        }
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === index && (
                                        <div className={styles.menu}>
                                            {r.status === "Pending" && (
                                                <>
                                                    <button className={styles.approve}>Approve</button>
                                                    <button className={styles.reject}>Reject</button>
                                                </>
                                            )}
                                            <button className={styles.view}>View</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default WithdrawalRequests;
