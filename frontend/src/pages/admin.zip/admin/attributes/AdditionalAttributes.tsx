import React from 'react';
import styles from './AdditionalAttributes.module.css';

const AdditionalAttributes: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Additional Attributes</h1>
            <p>Welcome to the Additional Attributes management module.</p>
        </div>
    );
};

export default AdditionalAttributes;