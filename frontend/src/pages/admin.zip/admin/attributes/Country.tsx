import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const countries: Member[] = [
    {
        id: 1,
        code: "CTRY-IN",
        name: "India",
        phone: "+91",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "Region",
        since: "N/A",
        status: "Active",
        image: "/flag_in.png",
    },
    {
        id: 2,
        code: "CTRY-US",
        name: "USA",
        phone: "+1",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "Region",
        since: "N/A",
        status: "Active",
        image: "/flag_us.png",
    }
];

const Country: React.FC = () => {
    return <MemberTable title="Countries" initialMembers={countries} />;
};

export default Country;