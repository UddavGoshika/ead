import React from 'react';
import styles from './FamilyValues.module.css';

const FamilyValues: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Family Values</h1>
            <p>Welcome to the Family Values management module.</p>
        </div>
    );
};

export default FamilyValues;