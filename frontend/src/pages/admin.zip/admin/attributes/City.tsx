import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const cities: Member[] = [
    {
        id: 1,
        code: "CITY-ND",
        name: "New Delhi",
        phone: "Delhi",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "City",
        since: "N/A",
        status: "Active",
        image: "/city_icon.png",
    },
    {
        id: 2,
        code: "CITY-MB",
        name: "Mumbai",
        phone: "Maharashtra",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "City",
        since: "N/A",
        status: "Active",
        image: "/city_icon.png",
    }
];

const City: React.FC = () => {
    return <MemberTable title="Cities" initialMembers={cities} />;
};

export default City;