import React from 'react';
import styles from './AnnualSalary.module.css';

const AnnualSalary: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Annual Salary</h1>
            <p>Welcome to the Annual Salary management module.</p>
        </div>
    );
};

export default AnnualSalary;