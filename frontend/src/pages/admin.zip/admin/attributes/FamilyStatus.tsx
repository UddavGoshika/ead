import React from 'react';
import styles from './FamilyStatus.module.css';

const FamilyStatus: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Family Status</h1>
            <p>Welcome to the Family Status management module.</p>
        </div>
    );
};

export default FamilyStatus;