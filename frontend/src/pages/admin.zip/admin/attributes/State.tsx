import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const states: Member[] = [
    {
        id: 1,
        code: "STAT-DL",
        name: "Delhi",
        phone: "India",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "State",
        since: "N/A",
        status: "Active",
        image: "/state_icon.png",
    },
    {
        id: 2,
        code: "STAT-MH",
        name: "Maharashtra",
        phone: "India",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "State",
        since: "N/A",
        status: "Active",
        image: "/state_icon.png",
    }
];

const State: React.FC = () => {
    return <MemberTable title="States" initialMembers={states} />;
};

export default State;