import React from 'react';
import styles from './SubCaste.module.css';

const SubCaste: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Sub Caste</h1>
            <p>Welcome to the Sub Caste management module.</p>
        </div>
    );
};

export default SubCaste;