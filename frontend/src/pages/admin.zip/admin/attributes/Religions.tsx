import React from 'react';
import styles from './Religions.module.css';

const Religions: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Religions</h1>
            <p>Welcome to the Religions management module.</p>
        </div>
    );
};

export default Religions;