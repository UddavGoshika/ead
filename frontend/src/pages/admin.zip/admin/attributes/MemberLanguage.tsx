import React from "react";
import MemberTable from "../../../components/admin/MemberTable";
import type { Member } from "../../../components/admin/MemberTable";

const languages: Member[] = [
    {
        id: 1,
        code: "LANG-01",
        name: "English",
        phone: "Universal",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "System",
        since: "N/A",
        status: "Active",
        image: "/lang_icon.png",
    },
    {
        id: 2,
        code: "LANG-02",
        name: "Hindi",
        phone: "Regional",
        gender: "N/A",
        verified: true,
        reported: 0,
        plan: "System",
        since: "N/A",
        status: "Active",
        image: "/lang_icon.png",
    }
];

const MemberLanguage: React.FC = () => {
    return <MemberTable title="Member Languages" initialMembers={languages} />;
};

export default MemberLanguage;