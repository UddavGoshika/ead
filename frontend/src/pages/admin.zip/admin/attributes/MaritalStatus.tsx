import React from 'react';
import styles from './MaritalStatus.module.css';

const MaritalStatus: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Marital Status</h1>
            <p>Welcome to the Marital Status management module.</p>
        </div>
    );
};

export default MaritalStatus;