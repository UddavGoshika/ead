import React from 'react';
import styles from './Caste.module.css';

const Caste: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Caste</h1>
            <p>Welcome to the Caste management module.</p>
        </div>
    );
};

export default Caste;