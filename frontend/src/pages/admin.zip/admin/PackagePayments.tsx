import React from "react";
import styles from "./PackagePayments.module.css";

/* ================= TYPES ================= */
type PaymentStatus = "Paid" | "Unpaid";

interface Payment {
    id: number;
    memberName: string;
    memberId: string;
    packageName: string;
    paymentMethod: string;
    amount: string;
    status: PaymentStatus;
    paymentCode: string;
    purchaseDate: string;
}

/* ================= MOCK DATA ================= */
const payments: Payment[] = [
    {
        id: 1,
        memberName: "Rohan Mehta",
        memberId: "123456",
        packageName: "Silver",
        paymentMethod: "Bank transfer",
        amount: "40.00$",
        status: "Paid",
        paymentCode: "250803-223602",
        purchaseDate: "2025-08-03 12:36:02",
    },
    {
        id: 2,
        memberName: "Arhaan Malik",
        memberId: "123456",
        packageName: "Silver",
        paymentMethod: "Bank transfer",
        amount: "40.00$",
        status: "Unpaid",
        paymentCode: "250803-221822",
        purchaseDate: "2025-08-03 12:18:22",
    },
    {
        id: 3,
        memberName: "Arhaan Malik",
        memberId: "123456",
        packageName: "Silver",
        paymentMethod: "Bank transfer",
        amount: "40.00$",
        status: "Unpaid",
        paymentCode: "250803-221650",
        purchaseDate: "2025-08-03 12:16:50",
    },
    {
        id: 4,
        memberName: "Dustin Henderson",
        memberId: "123456",
        packageName: "Gold",
        paymentMethod: "Bank transfer",
        amount: "50.00$",
        status: "Paid",
        paymentCode: "250714-183146",
        purchaseDate: "2025-07-14 08:31:46",
    },
    {
        id: 5,
        memberName: "Dustin Henderson",
        memberId: "123456",
        packageName: "Silver",
        paymentMethod: "Bank transfer",
        amount: "40.00$",
        status: "Paid",
        paymentCode: "250714-182258",
        purchaseDate: "2025-07-14 08:22:58",
    },
    {
        id: 6,
        memberName: "James Logan",
        memberId: "123456",
        packageName: "Gold",
        paymentMethod: "Bank transfer",
        amount: "50.00$",
        status: "Unpaid",
        paymentCode: "250601-194820",
        purchaseDate: "2025-06-01 09:48:20",
    },
    {
        id: 7,
        memberName: "James Logan",
        memberId: "123456",
        packageName: "Gold",
        paymentMethod: "Bank transfer",
        amount: "50.00$",
        status: "Paid",
        paymentCode: "250601-194628",
        purchaseDate: "2025-06-01 09:46:28",
    },
];

/* ================= COMPONENT ================= */
const PackagePaymentList: React.FC = () => {
    return (
        <div className={styles.page}>
            <h2 className={styles.pageTitle}>Package Payment List</h2>

            <div className={styles.card}>
                <h3 className={styles.cardTitle}>All Payments</h3>

                <div className={styles.tableWrapper}>
                    <table className={styles.table}>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Member Name</th>
                                <th>Member ID</th>
                                <th>Package</th>
                                <th>Payment Method</th>
                                <th>Amount</th>
                                <th>Payment Status</th>
                                <th>Payment Code</th>
                                <th>Purchase Date</th>
                                <th>Options</th>
                            </tr>
                        </thead>

                        <tbody>
                            {payments.map((p, index) => (
                                <tr key={p.id}>
                                    <td>{index + 1}</td>
                                    <td>{p.memberName}</td>
                                    <td>{p.memberId}</td>
                                    <td>{p.packageName}</td>
                                    <td>{p.paymentMethod}</td>
                                    <td>{p.amount}</td>
                                    <td>
                                        <span
                                            className={`${styles.badge} ${p.status === "Paid"
                                                ? styles.paid
                                                : styles.unpaid
                                                }`}
                                        >
                                            {p.status}
                                        </span>
                                    </td>
                                    <td>{p.paymentCode}</td>
                                    <td>{p.purchaseDate}</td>
                                    <td>
                                        <div className={styles.actions}>
                                            <button className={styles.viewBtn}>👁</button>
                                            <button className={styles.invoiceBtn}>📄</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                {/* ================= PAGINATION ================= */}
                <div className={styles.pagination}>
                    <button className={styles.pageBtn}>‹</button>
                    <button className={`${styles.pageBtn} ${styles.active}`}>1</button>
                    <button className={styles.pageBtn}>2</button>
                    <button className={styles.pageBtn}>›</button>
                </div>
            </div>
        </div>
    );
};

export default PackagePaymentList;
