import React from 'react';
import styles from './SendSms.module.css';

const SendSms: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>Send SMS</h1>
            <p>Welcome to the Send SMS management module.It is Under Development</p>
        </div>
    );
};

export default SendSms;