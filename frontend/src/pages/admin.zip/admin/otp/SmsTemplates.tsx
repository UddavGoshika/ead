import React from 'react';
import styles from './SmsTemplates.module.css';

const SmsTemplates: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>SMS Templates</h1>
            <p>Welcome to the SMS Templates management module. It is Under Development.we will update it soon.</p>
        </div>
    );
};

export default SmsTemplates;