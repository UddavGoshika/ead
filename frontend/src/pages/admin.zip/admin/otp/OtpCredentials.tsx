import React from 'react';
import styles from './OtpCredentials.module.css';

const OtpCredentials: React.FC = () => {
    return (
        <div className={styles.container}>
            <h1>OTP Credentials</h1>
            <p>Welcome to the OTP Credentials management module. It is Under Development.we will update it soon.</p>
        </div>
    );
};

export default OtpCredentials;