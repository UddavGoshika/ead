import React, { useState } from "react";
import styles from "./PremiumPackages.module.css";

/* ================= TYPES ================= */
interface Tier {
    name: "Silver" | "Gold" | "Platinum";
    price: number;
    active: boolean;
}

interface Plan {
    name: "Free" | "Pro Lite" | "Pro" | "Ultimate Pro";
    tiers: Tier[];
}

/* ================= DATA ================= */
const initialPlans: Plan[] = [
    {
        name: "Free",
        tiers: [
            { name: "Silver", price: 0, active: true },
            { name: "Gold", price: 0, active: true },
            { name: "Platinum", price: 0, active: true },
        ],
    },
    {
        name: "Pro Lite",
        tiers: [
            { name: "Silver", price: 40, active: true },
            { name: "Gold", price: 60, active: true },
            { name: "Platinum", price: 80, active: false },
        ],
    },
    {
        name: "Pro",
        tiers: [
            { name: "Silver", price: 70, active: true },
            { name: "Gold", price: 100, active: true },
            { name: "Platinum", price: 150, active: true },
        ],
    },
    {
        name: "Ultimate Pro",
        tiers: [
            { name: "Silver", price: 150, active: true },
            { name: "Gold", price: 200, active: true },
            { name: "Platinum", price: 300, active: true },
        ],
    },
];

/* ================= COMPONENT ================= */
const MembershipPackages: React.FC = () => {
    const [plans, setPlans] = useState(initialPlans);
    const [expanded, setExpanded] = useState<Record<string, boolean>>({});

    const toggleTier = (planIndex: number, tierIndex: number) => {
        setPlans(prev =>
            prev.map((plan, pIdx) =>
                pIdx === planIndex
                    ? {
                        ...plan,
                        tiers: plan.tiers.map((tier, tIdx) =>
                            tIdx === tierIndex
                                ? { ...tier, active: !tier.active }
                                : tier
                        ),
                    }
                    : plan
            )
        );
    };

    const toggleExpand = (planName: string) => {
        setExpanded(prev => ({
            ...prev,
            [planName]: !prev[planName],
        }));
    };

    return (
        <div className={styles.page}>
            {/* ================= HEADER ================= */}
            <div className={styles.header}>
                <h2>Membership Packages</h2>
                <button className={styles.addBtn}>+ Add New Package</button>


            </div>


            {/* ================= PLANS ================= */}
            <div className={styles.planGrid}>
                {plans.map((plan, planIndex) => (
                    <div key={plan.name} className={styles.planCard}>
                        {/* PLAN HEADER */}
                        <div
                            className={styles.planHeader}
                            onClick={() => toggleExpand(plan.name)}
                        >
                            <h3>{plan.name}</h3>
                            <span className={styles.expandIcon}>
                                {expanded[plan.name] ? "−" : "+"}
                            </span>
                        </div>

                        {/* TIERS */}
                        {expanded[plan.name] && (
                            <table className={styles.table}>
                                <thead>
                                    <tr>
                                        <th>Tier</th>
                                        <th>Price</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {plan.tiers.map((tier, tierIndex) => (
                                        <tr key={tier.name}>
                                            <td>
                                                <span
                                                    className={`${styles.tierBadge} ${styles[tier.name.toLowerCase()]
                                                        }`}
                                                >
                                                    {tier.name}
                                                </span>
                                            </td>

                                            <td>₹{tier.price}</td>

                                            <td>
                                                <label className={styles.switch}>
                                                    <input
                                                        type="checkbox"
                                                        checked={tier.active}
                                                        onChange={() =>
                                                            toggleTier(planIndex, tierIndex)
                                                        }
                                                    />
                                                    <span className={styles.slider}></span>
                                                </label>
                                            </td>

                                            <td>
                                                <div className={styles.actions}>
                                                    <button className={styles.editBtn}>✏️</button>
                                                    <button className={styles.deleteBtn}>🗑️</button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default MembershipPackages;
