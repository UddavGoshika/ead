import React, { useState } from "react";
import styles from "./AllPosts.module.css";

type PostStatus = "Draft" | "Pending Review" | "Published";

type Post = {
    id: string;
    title: string;
    author: string;
    category: string;
    views: string;
    comments: number;
    status: PostStatus;
    published: string;
};

const posts: Post[] = [
    {
        id: "POST4000",
        title: "Success Stories from Our Users 1",
        author: "Author 4",
        category: "Tutorial",
        views: "1,468",
        comments: 71,
        status: "Draft",
        published: "16/03/2025",
    },
    {
        id: "POST4001",
        title: "Advanced Features Guide 2",
        author: "Author 4",
        category: "Guide",
        views: "3,306",
        comments: 88,
        status: "Pending Review",
        published: "26/04/2025",
    },
    {
        id: "POST4002",
        title: "Monthly Updates Roundup 3",
        author: "Author 1",
        category: "Guide",
        views: "3,596",
        comments: 43,
        status: "Draft",
        published: "26/09/2025",
    },
    {
        id: "POST4007",
        title: "Success Stories from Our Users 8",
        author: "Author 5",
        category: "Update",
        views: "7,515",
        comments: 92,
        status: "Published",
        published: "26/02/2025",
    },
];

const BlogPosts: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<string | null>(null);

    return (
        <div className={styles.page}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Blog Posts</h2>
                <div className={styles.headerActions}>
                    <button className={styles.outlineBtn}>📁 Categories</button>
                    <button className={styles.primaryBtn}>📝 New Post</button>
                </div>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Category</th>
                            <th>Views</th>
                            <th>Comments</th>
                            <th>Status</th>
                            <th>Published</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {posts.map((post) => (
                            <tr key={post.id}>
                                <td>
                                    <div className={styles.titleCell}>
                                        <div className={styles.icon}>📄</div>
                                        <div>
                                            <strong>{post.title}</strong>
                                            <small>ID: {post.id}</small>
                                        </div>
                                    </div>
                                </td>
                                <td>{post.author}</td>
                                <td>
                                    <span className={`${styles.badge} ${styles.category}`}>
                                        {post.category}
                                    </span>
                                </td>
                                <td>{post.views}</td>
                                <td>{post.comments}</td>
                                <td>
                                    <span
                                        className={`${styles.badge} ${styles[post.status.replace(" ", "").toLowerCase()]
                                            }`}
                                    >
                                        {post.status}
                                    </span>
                                </td>
                                <td>{post.published}</td>
                                <td className={styles.actions}>
                                    <button
                                        className={styles.menuBtn}
                                        onClick={() =>
                                            setOpenMenu(openMenu === post.id ? null : post.id)
                                        }
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === post.id && (
                                        <div className={styles.menu}>
                                            <button>Edit</button>
                                            <button>View</button>
                                            <button className={styles.danger}>Delete</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default BlogPosts;
