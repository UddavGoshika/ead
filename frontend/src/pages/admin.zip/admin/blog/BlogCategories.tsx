import React, { useState } from "react";
import styles from "./BlogCategories.module.css";

type CategoryStatus = "Active" | "Inactive";

type Category = {
    name: string;
    posts: number;
    slug: string;
    status: CategoryStatus;
};

const categories: Category[] = [
    { name: "Success Stories", posts: 24, slug: "success-stories", status: "Active" },
    { name: "Dating Tips", posts: 18, slug: "dating-tips", status: "Active" },
    { name: "Relationship Advice", posts: 32, slug: "relationship-advice", status: "Active" },
    { name: "Wedding Planning", posts: 12, slug: "wedding-planning", status: "Active" },
    { name: "Culture & Traditions", posts: 8, slug: "culture-&-traditions", status: "Inactive" },
    { name: "Announcements", posts: 5, slug: "announcements", status: "Active" },
];

const BlogCategories: React.FC = () => {
    const [openMenu, setOpenMenu] = useState<number | null>(null);

    return (
        <div className={styles.page}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Blog Categories</h2>
                <button className={styles.addBtn}>＋ Add Category</button>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Category Name</th>
                            <th>Posts Count</th>
                            <th>Slug</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {categories.map((cat, index) => (
                            <tr key={cat.slug}>
                                <td className={styles.nameCell}>
                                    <span className={styles.icon}>📁</span>
                                    {cat.name}
                                </td>
                                <td>{cat.posts} posts</td>
                                <td className={styles.slug}>{cat.slug}</td>
                                <td>
                                    <span
                                        className={`${styles.status} ${cat.status === "Active" ? styles.active : styles.inactive
                                            }`}
                                    >
                                        {cat.status}
                                    </span>
                                </td>
                                <td className={styles.actions}>
                                    <button
                                        className={styles.menuBtn}
                                        onClick={() =>
                                            setOpenMenu(openMenu === index ? null : index)
                                        }
                                    >
                                        ⋮
                                    </button>

                                    {openMenu === index && (
                                        <div className={styles.menu}>
                                            <button>Edit</button>
                                            <button className={styles.danger}>Delete</button>
                                        </div>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default BlogCategories;
