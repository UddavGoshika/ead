import React from "react";
import styles from "./StaffRoles.module.css";

type Role = {
    name: string;
    level: string;
    staffCount: number;
    status: "Active" | "Inactive";
    highlight?: boolean;
};

const roles: Role[] = [
    { name: "Super Admin", level: "All", staffCount: 2, status: "Active" },
    { name: "Administrator", level: "Most", staffCount: 3, status: "Active" },
    { name: "Moderator", level: "Moderate", staffCount: 5, status: "Active" },
    {
        name: "Support Agent",
        level: "Support",
        staffCount: 4,
        status: "Active",
        highlight: true,
    },
    { name: "Content Manager", level: "Content", staffCount: 2, status: "Active" },
    {
        name: "Finance Manager",
        level: "Financial",
        staffCount: 1,
        status: "Inactive",
    },
];

const StaffRoles: React.FC = () => {
    return (
        <div className={styles.card}>
            <div className={styles.header}>
                <h2>Staff Roles & Permissions</h2>
                <button className={styles.addBtn}>＋ Add Role</button>
            </div>

            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Role Name</th>
                        <th>Permission Level</th>
                        <th>Staff Count</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    {roles.map((role) => (
                        <tr
                            key={role.name}
                            className={role.highlight ? styles.highlight : ""}
                        >
                            <td className={styles.role}>{role.name}</td>
                            <td>{role.level}</td>
                            <td>{role.staffCount} staff</td>
                            <td>
                                <span
                                    className={
                                        role.status === "Active"
                                            ? styles.active
                                            : styles.inactive
                                    }
                                >
                                    {role.status}
                                </span>
                            </td>
                            <td className={styles.actions}>
                                <button className={styles.edit}>Edit</button>
                                <button className={styles.permissions}>Permissions</button>
                                <button className={styles.delete}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default StaffRoles;
