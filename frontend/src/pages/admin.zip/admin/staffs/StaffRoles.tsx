import React from "react";
import StaffActions from "./staffactions";
import styles from "./StaffRoles.module.css";

type Staff = {
    id: string;
    name: string;
    email: string;
    role: string;
    permissions: number;
    status: "Active" | "Inactive";
    lastActive: string;
};

const staffData: Staff[] = [
    {
        id: "STAFF6000",
        name: "Staff Member 1",
        email: "staff6000@enterprise.com",
        role: "Moderator",
        permissions: 6,
        status: "Active",
        lastActive: "14/01/2026",
    },
    {
        id: "STAFF6001",
        name: "Staff Member 2",
        email: "staff6001@enterprise.com",
        role: "Developer",
        permissions: 6,
        status: "Active",
        lastActive: "15/01/2026",
    },
    {
        id: "STAFF6002",
        name: "Staff Member 3",
        email: "staff6002@enterprise.com",
        role: "Admin",
        permissions: 6,
        status: "Inactive",
        lastActive: "18/01/2026",
    },
    {
        id: "STAFF6003",
        name: "Staff Member 4",
        email: "staff6003@enterprise.com",
        role: "Support",
        permissions: 6,
        status: "Inactive",
        lastActive: "16/01/2026",
    },
    {
        id: "STAFF6004",
        name: "Staff Member 5",
        email: "staff6004@enterprise.com",
        role: "Developer",
        permissions: 0,
        status: "Active",
        lastActive: "17/01/2026",
    },
    {
        id: "STAFF6005",
        name: "Staff Member 6",
        email: "staff6005@enterprise.com",
        role: "Admin",
        permissions: 7,
        status: "Active",
        lastActive: "13/01/2026",
    },
    {
        id: "STAFF6006",
        name: "Staff Member 7",
        email: "staff6006@enterprise.com",
        role: "Developer",
        permissions: 4,
        status: "Inactive",
        lastActive: "16/01/2026",
    },
    {
        id: "STAFF6007",
        name: "Staff Member 8",
        email: "staff6007@enterprise.com",
        role: "Moderator",
        permissions: 6,
        status: "Active",
        lastActive: "12/01/2026",
    },
    {
        id: "STAFF6008",
        name: "Staff Member 9",
        email: "staff6008@enterprise.com",
        role: "Support",
        permissions: 5,
        status: "Active",
        lastActive: "13/01/2026",
    },
    {
        id: "STAFF6009",
        name: "Staff Member 10",
        email: "staff6009@enterprise.com",
        role: "Moderator",
        permissions: 5,
        status: "Active",
        lastActive: "15/01/2026",
    },
    {
        id: "STAFF6010",
        name: "Staff Member 11",
        email: "staff6010@enterprise.com",
        role: "Developer",
        permissions: 4,
        status: "Inactive",
        lastActive: "14/01/2026",
    },
    {
        id: "STAFF6011",
        name: "Staff Member 12",
        email: "staff6011@enterprise.com",
        role: "Moderator",
        permissions: 6,
        status: "Active",
        lastActive: "13/01/2026",
    },
];

const StaffMembers: React.FC = () => {
    return (
        <div className={styles.card}>
            <div className={styles.header}>
                <h2>Staff Members</h2>
                <button className={styles.addBtn}>＋ Add Staff</button>
            </div>

            <table className={styles.table}>
                <thead>
                    <tr>
                        <th>Staff ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Permissions</th>
                        <th>Status</th>
                        <th>Last Active</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                    {staffData.map((staff) => (
                        <tr key={staff.id}>
                            <td className={styles.id}>{staff.id}</td>

                            <td className={styles.name}>
                                <span className={styles.avatar}>S</span>
                                {staff.name}
                            </td>

                            <td>{staff.email}</td>
                            <td>{staff.role}</td>
                            <td>{staff.permissions} permissions</td>

                            <td>
                                <span
                                    className={
                                        staff.status === "Active"
                                            ? styles.active
                                            : styles.inactive
                                    }
                                >
                                    {staff.status}
                                </span>
                            </td>

                            <td>{staff.lastActive}</td>

                            <td>
                                <StaffActions
                                    onView={() => console.log("View", staff.id)}
                                    onEdit={() => console.log("Edit", staff.id)}
                                    onDelete={() => console.log("Delete", staff.id)}
                                />
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default StaffMembers;
