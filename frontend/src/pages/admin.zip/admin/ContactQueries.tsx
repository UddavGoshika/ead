import React from "react";
import styles from "./ContactQueries.module.css";

type QueryStatus = "New" | "In Progress" | "Resolved";

type Query = {
    id: string;
    name: string;
    email: string;
    type: string;
    subject: string;
    status: QueryStatus;
    created: string;
    assignedTo: string;
};

const queries: Query[] = [
    {
        id: "QUERY7000",
        name: "User 1",
        email: "user7000@example.com",
        type: "Bug Report",
        subject: "Query about payment",
        status: "In Progress",
        created: "03/01/2026",
        assignedTo: "Staff 1",
    },
    {
        id: "QUERY7001",
        name: "User 2",
        email: "user7001@example.com",
        type: "Account Problem",
        subject: "Query about profile",
        status: "In Progress",
        created: "02/01/2026",
        assignedTo: "Staff 5",
    },
    {
        id: "QUERY7002",
        name: "User 3",
        email: "user7002@example.com",
        type: "General Inquiry",
        subject: "Query about feature",
        status: "New",
        created: "11/01/2026",
        assignedTo: "Staff 2",
    },
    {
        id: "QUERY7003",
        name: "User 4",
        email: "user7003@example.com",
        type: "Bug Report",
        subject: "Query about payment",
        status: "Resolved",
        created: "25/12/2025",
        assignedTo: "Staff 3",
    },
];

const ContactQueries: React.FC = () => {
    return (
        <div className={styles.wrapper}>
            {/* HEADER */}
            <div className={styles.header}>
                <h2>Contact Us Queries</h2>
                <div className={styles.headerActions}>
                    <button className={styles.export}>Export</button>
                    <button className={styles.filter}>Filter</button>
                </div>
            </div>

            {/* TABLE */}
            <div className={styles.card}>
                <table className={styles.table}>
                    <thead>
                        <tr>
                            <th>Query ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Type</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Assigned To</th>
                            <th>Actions</th>
                        </tr>
                    </thead>

                    <tbody>
                        {queries.map((q) => (
                            <tr key={q.id}>
                                <td className={styles.id}>{q.id}</td>
                                <td>{q.name}</td>
                                <td>{q.email}</td>
                                <td>{q.type}</td>
                                <td>{q.subject}</td>
                                <td>
                                    <span
                                        className={`${styles.badge} ${q.status === "New"
                                            ? styles.new
                                            : q.status === "Resolved"
                                                ? styles.resolved
                                                : styles.inProgress
                                            }`}
                                    >
                                        {q.status}
                                    </span>
                                </td>
                                <td>{q.created}</td>
                                <td>{q.assignedTo}</td>
                                <td className={styles.actions}>
                                    <button className={styles.view}>View</button>

                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default ContactQueries;
